# M.R.G GHAFFARI Digital Card
Upload index.html, golden-card.png and mrg-ghaffari.vcf to the root of the GitHub repository. Then enable Settings > Pages > Deploy from a branch > main / (root).
The QR visible in the artwork is decorative, not yet a working QR. After publishing, replace it with a generated QR of the published GitHub Pages URL.
